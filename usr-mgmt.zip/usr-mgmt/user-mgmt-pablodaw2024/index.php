<?php

// Cargar dependencias y clases necesarias
require "vendor/autoload.php";
require "clases/DataBase.php";
require "clases/Usuario.php";
require "clases/Pintor.php";
require "clases/Cuadro.php";

// Usar el motor de plantillas BladeOne y la clase DataBase
use eftec\bladeone\BladeOne;
use DataBase\DataBase;

// Configurar rutas para vistas y cache
$views = __DIR__ . '\views';
$cache = __DIR__ . '\cache';

// Crear instancia de BladeOne
$blade = new BladeOne($views, $cache);
$blade->setBaseURL("http://localhost:8000");

// Iniciar sesion para manejar datos de usuario
session_start();

// Logica principal basada en las solicitudes
if (empty($_REQUEST) || isset($_POST['cerrarSesion'])) {
    // Mostrar formulario de registro con la lista de pintores
    $pintores = Pintor::recuperaPintores(DataBase::getConexion());
    $_SESSION['pintores'] = $pintores;
    echo $blade->run('register', ['pintores' => $pintores]);
} elseif (isset($_POST['registrarse'])) {
    // Registrar un nuevo usuario
    $nombre = filter_input(INPUT_POST, 'usuario');
    $email = filter_input(INPUT_POST, 'email');
    $contraseña = filter_input(INPUT_POST, 'contraseña');
    $pintor = filter_input(INPUT_POST, 'pintores');
    $id = null;

    // Crear instancia de Usuario
    $usuario = new Usuario($id, $nombre, $contraseña, $email, $pintor);

    // Guardar usuario en la base de datos
    if ($usuario->persiste(DataBase::getConexion())) {
        $texto = "Registrado correctamente !";
        echo $blade->run('login', ['texto' => $texto]);
    } else {
        $textoError = "ERROR";
        echo $blade->run('register');
    }
} elseif (isset($_POST['irLogin'])) {
    // Mostrar formulario de login
    $texto = "";
    echo $blade->run('login', ['texto' => $texto]);
} elseif (isset($_POST['login'])) {
    // Iniciar sesion con credenciales
    $nombreUsuario = filter_input(INPUT_POST, 'usuario');
    $contra = filter_input(INPUT_POST, 'contraseña');
    $_SESSION['nombre'] = $nombreUsuario;
    $_SESSION['contra'] = $contra;

    // Recuperar usuario de la base de datos
    $usuario = Usuario::recuperaUsuarioPorCredenciales((DataBase::getConexion()), $nombreUsuario, $contra);

    if (!is_null($usuario)) {
        // Obtener datos del pintor y sus cuadros
        $pintorObjeto = $usuario->getPintor();
        $nombrePintor = $pintorObjeto->getNombre();
        $cuadros = $pintorObjeto->getPaintings();

        // Guardar datos en sesion
        $_SESSION['usuarios'] = $usuario;
        $_SESSION['nombrePintor'] = $nombrePintor;
        $_SESSION['cuadros'] = $cuadros;

        // Mostrar contenido principal
        echo $blade->run('contenido', ['nombre' => $usuario->getNombre(), 'cuadros' => $cuadros]);
    } else {
        // Mostrar error si las credenciales son incorrectas
        $texto = "Credenciales incorrectas !";
        echo $blade->run('login', ['texto' => $texto]);
    }
} elseif (isset($_POST['volver'])) {
    // Volver al contenido principal
    $usuario = $_SESSION['usuarios'];
    $cuadros = $_SESSION['cuadros'];
    echo $blade->run('contenido', ['nombre' => $usuario->getNombre(), 'cuadros' => $cuadros]);
} elseif (isset($_POST['borrar'])) {
    // Borrar usuario
    $usuario = $_SESSION['usuarios'];
    $pintores = $_SESSION['pintores'];
    $usuario->borra(DataBase::getConexion(), $_SESSION['nombre']);

    // Actualizar datos en sesion
    $_SESSION['usuarios'] = $usuario;
    $_SESSION['pintores'] = $pintores;

    // Mostrar formulario de registro
    echo $blade->run('register', ['pintores' => $pintores]);
} elseif (isset($_POST['irCambiarDatos'])) {
    // Mostrar formulario para cambiar datos del usuario
    $usuario = $_SESSION['usuarios'];
    $pintores = $_SESSION['pintores'];
    $nombrePintor = $_SESSION['nombrePintor'];
    echo $blade->run('cambiarDatos', ['nombre' => $usuario->getNombre(), 'contra' => $usuario->getContraseña(), 'email' => $usuario->getEmail(), 'pintores' => $pintores, 'pintorViejo' => $nombrePintor]);
} elseif (isset($_POST['guardar'])) {
    // Guardar cambios en los datos del usuario
    $nuevoNombre = filter_input(INPUT_POST, 'nuevoNombre');
    $nuevoEmail = filter_input(INPUT_POST, 'nuevoEmail');
    $nuevaContraseña = filter_input(INPUT_POST, 'nuevaContraseña');
    $nuevoPintor = filter_input(INPUT_POST, 'nuevosPintores');
    $nuevoId = null;

    // Actualizar datos del usuario
    $usuario = $_SESSION['usuarios'];
    $usuario->setNombre($nuevoNombre);
    $usuario->setContraseña($nuevaContraseña);
    $usuario->setEmail($nuevoEmail);
    $usuario->setPintor($nuevoPintor);

    // Guardar cambios en la base de datos
    $usuario->persiste(DataBase::getConexion());
    $usuario = Usuario::recuperaUsuarioPorCredenciales((DataBase::getConexion()), $nuevoNombre, $nuevaContraseña);
    $pintorObjeto = $usuario->getPintor();
    $nombrePintor = $pintorObjeto->getNombre();
    $cuadros = $pintorObjeto->getPaintings();

    // Actualizar datos en sesion
    $_SESSION['usuarios'] = $usuario;
    $_SESSION['nombrePintor'] = $nombrePintor;
    $_SESSION['cuadros'] = $cuadros;

    // Mostrar contenido principal con mensaje de exito
    $texto = "Datos cambiados correctamente!";
    echo $blade->run('contenido', ['nombre' => $usuario->getNombre(), 'cuadros' => $cuadros]);
}

// Mostrar detalles de un cuadro especifico
if (isset($_REQUEST['id'])) {
    $idCuadro = $_REQUEST['id'];
    $cuadros = $_SESSION['cuadros'];
    $nombrePintor = $_SESSION['nombrePintor'];

    // Buscar el cuadro por su ID
    foreach ($cuadros as $cuadro) {
        if ($cuadro->getId() == $idCuadro) {
            $titulo = $cuadro->getTitulo();
            $img = $cuadro->getImagen();
            $año = $cuadro->getAño();
            $descripcion = $cuadro->getDescripcion();
            $epoca = $cuadro->getEpoca();
        }
    }

    // Mostrar vista detallada del cuadro
    echo $blade->run('contenidoDetallado', ['titulo' => $titulo, 'img' => $img, 'año' => $año, 'descripcion' => $descripcion, 'epoca' => $epoca, 'pintor' => $nombrePintor]);
}