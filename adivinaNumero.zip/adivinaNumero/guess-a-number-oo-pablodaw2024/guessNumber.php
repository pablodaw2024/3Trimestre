<?php


class guessNumber {
    
    public $intentos;        // Numero de intentos restantes
    public $numMin;          // Numero minimo del rango
    public $numMax;          // Numero maximo del rango
    public $numeroAleatorio; // Numero aleatorio generado

    // Inicializamos el juego
    function __construct($intentos, $numMin, $numMax) {
        $this->intentos = $intentos;               // Guarda el numero de intentos
        $this->numMin = $numMin;                   // Guarda el numero minimo
        $this->numMax = $numMax;                   // Guarda el numero maximo
        $this->numeroAleatorio = rand($numMin, $numMax); // Genera un numero aleatorio
    }

    // Metodo para verificar si el usuario adivino el número
    public function adivinar($numeroUsuario) {
        $veredicto; // Variable para almacenar el resultado
        if ($numeroUsuario == $this->numeroAleatorio) {
            $veredicto = true; 
        }
        if ($numeroUsuario > $this->numeroAleatorio) {
            $this->intentos--; // Reduce intentos si el numero es mayor
            $veredicto = false;
        } elseif ($numeroUsuario < $this->numeroAleatorio) {
            $this->intentos--; // Reduce intentos si el numero es menor
            $veredicto = false;
        }
        return $veredicto;
    }

    // Metodo para verificar si el juego ha terminado
    public function final() {
        $final = false;
        if ($this->intentos == 0) {
            $final = true; // El juego termina si no hay intentos
        }
        return $final; // Devuelve si el juego ha terminado o no
    }

    // Metodo para obtener los intentos restantes
    public function obtenerIntentos() {
        return $this->intentos;
    }

    // Metodo para obtener el número aleatorio generado
    public function obtenerNumeroAleatorio() {
        return $this->numeroAleatorio;
    }

}