<?php


require "vendor/autoload.php";
include 'guessNumber.php';

use eftec\bladeone\BladeOne;


$views = __DIR__ . '\views';
$cache = __DIR__ . '\cache';
$blade = new BladeOne($views, $cache);
$blade->setBaseURL("http://localhost:8000");

// Iniciamos la sesion
session_start();

if (empty($_POST) || isset($_POST['juegoNuevo'])) {
    //Como esta vacio muestra la pantalla inicial
    echo $blade->run('gameconfig');
} elseif (isset($_POST['jugar'])) {
    // Obtenemos los numeros del formulario y comprobamos que sean numeros
    $intentos = filter_input(INPUT_POST, 'intentos', FILTER_SANITIZE_NUMBER_INT);
    $numMax = filter_input(INPUT_POST, 'max', FILTER_SANITIZE_NUMBER_INT);
    $numMin = filter_input(INPUT_POST, 'min', FILTER_SANITIZE_NUMBER_INT);

    // Validamos los datos y si estan vacios mostramos la pantalla inicial
    if (empty($intentos) || empty($numMax) || empty($numMin)) {
        echo $blade->run('gameconfig');
    } else {
        // Creamos la instancia del juego y guardamos en sesiones
        $claseJuego = new guessNumber($intentos, $numMin, $numMax);
        $_SESSION['claseJuego'] = $claseJuego;
        $_SESSION['intentos'] = $intentos;
        // Mostramos la vista del juego
        echo $blade->run('juego', ['info' => "", 'intentosrestantes' => $intentos]);
    }
} elseif (isset($_POST['apostar'])) {
    // Obtenemos el numero apostado por el usuario
    $numeroUsuario = filter_input(INPUT_POST, 'numero');
    $claseJuego = $_SESSION['claseJuego'];

    // Verificamos si el numero es correcto y obtenemos los datos del juego
    $adivinar = $claseJuego->adivinar($numeroUsuario);
    $intentos = $claseJuego->obtenerIntentos();
    $numeroAleatorio = $claseJuego->obtenerNumeroAleatorio();
    $final = ($intentos == 0 || $numeroUsuario == $numeroAleatorio);

    // Verificamos si el usuario ha perdido
    $perder = $claseJuego->final($numeroUsuario);

    // Mensajes para el usuario
    $info = "";
    $veredicto = "";

    if ($adivinar) {
        $veredicto = "Has ganado!!";
    } else {
        // Damos la pista si el numero es mayor o menor
        if ($numeroUsuario < $numeroAleatorio) {
            $info = "El numero es mayor";
        } else {
            $info = "El numero es menor";
        }
    }
    if ($perder) {
        $veredicto = "Has perdido!!";
    }

    // Mostramos vista final o continuar el juego
    if ($final) {
        echo $blade->run('final', ['info' => $info, 'intentosrestantes' => $intentos, 'veredicto' => $veredicto]);
    } else {
        echo $blade->run('juego', ['info' => $info, 'intentosrestantes' => $intentos]);
    }
}