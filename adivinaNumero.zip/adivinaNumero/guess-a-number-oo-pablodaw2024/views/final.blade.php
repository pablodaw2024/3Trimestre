@extends('app')
@section('content')

<form class="form-font capaform" name="GuessNumber" 
      action="index.php" method="POST">
    <div class="flex-outer">
        <div class="form-section">
            <h2>Se acabó!!</h2>

        </div>

        <div class="final">
            <h3>{{$veredicto}}</h3>
        </div>
    </div>
    <div class="submit-section">
        <input class="submit" type="submit" 
               value="Jugar de nuevo" name="juegoNuevo" />
    </div>
</form> 
@endsection