@extends('app')
@section('content')

<form class="form-font capaform" name="gameconfig" 
      action="index.php" method="POST">
    <div class="flex-outer">
        <div class="form-section">
            <div>
                <p>
                    <label for="numero">Escoge un numero de intentos:</label>
                    <input type="number" name="intentos" min="1" max="50"/>
                </p>

                <p>
                    <label for="numero">Escoge el numero minimo del rango:</label>
                    <input type="number" name="min" id="min"/>
                </p>

                <p>
                    <label for="numero">Escoge el numero maximo del rango:</label>
                    <input type="number" name="max" id="max"/>
                </p>
            </div>

        </div>
    </div>
    <div class="form-section">
        <div class="submit-section">
            <input class="submit" type="submit" 
                   value="Jugar" name="jugar" />
        </div>
    </div>
</form> 
@endsection
