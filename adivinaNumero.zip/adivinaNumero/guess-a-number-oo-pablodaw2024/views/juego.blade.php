@extends('app')
@section('content')
<form class="form-font capaform" name="juego" 
      action="index.php" method="POST">
    <div class="flex-outer">
        <div class="form-section">
            <div>
                <label for="numero">Escoge un numero:</label>
                <input type="number" name="numero" min="1" max="50"/>
            </div>

        </div>
        <div class="intentos">
            <p>{{$intentosrestantes}} intentos</p>
        </div>
        <div class="info">
            <p>{{$info}}</p>
        </div>
    </div>
    <div class="form-section">
        <div class="submit-section">
            <input class="submit" type="submit" 
                   value="Apostar" name="apostar" />
        </div>
    </div>
</form> 
@endsection