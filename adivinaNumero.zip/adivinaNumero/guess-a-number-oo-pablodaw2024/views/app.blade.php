<!DOCTYPE html>
<html>
    <head>
        <title>Adivina el número</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width">
        <link rel="stylesheet" type="text/css" href="/public/assets/css/stylesheet.css">
    </head>
    <body>
        <div class="flex-page">
            <h1>Adivina el numero</h1>
            <div class="contenido">
                @yield('content')
            </div>
        </div>
    </body>
</html>

